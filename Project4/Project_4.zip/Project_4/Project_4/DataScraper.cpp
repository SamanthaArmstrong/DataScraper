/******************************************************************************
//complete header documentation
TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO
******************************************************************************/

#include <iostream>
#include <string>
#include <fstream>
#include <streambuf>
using namespace std;

string getPageContents(string fileName);
/******************************************************************************
//complete function declarations
TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO
******************************************************************************/

int main(){

	string webpage;
	string begTag;
	string endTag;

	int beg = 0;
	int end = 0;
	int len;

	webpage = getPageContents("Source.htm");

	//update based on requirements and transform into scrapeDataIntoArray function
	//This function will then be called 6 times from here (once for each array)
	begTag = "<h4>";
	endTag = "</h4>";

	//find the first instance
	beg = webpage.find(begTag, beg);

	while(beg != -1){
		//move the beg index to after the end of the tag and find end index
		beg += begTag.length();
		end = webpage.find(endTag, beg);

		//compute the length of the substring based on the beg and end indeces
		len = end - beg;

          //output demonstration (don't keep, but can be used for testing)
		cout << webpage.substr(beg, len) << endl;

		//move beg to end of the ending tag and find the next begin tag
		beg = end + endTag.length();
		beg = webpage.find(begTag, beg);
	}
	//end scrapeDataIntoArray portion

	
	//writeSchools(/*fill in argument list*/);

	//computeAvgs(/*fill in argument list*/);

	//while(searchName != END){
	//	cout << "\nPlease enter a school name to search for (# to stop): ";
	//	getline(cin, searchName);
     //
	//	if(searchName != END){
	//		searchByName(/*fill in argument list*/);
	//	}
	//}

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//Get the contents of an input file and store into a string
//variable to be returned
///////////////////////////////////////////////////////////////////////////////
string getPageContents(string fileName){
	ifstream f(fileName);
	string str;

	f.seekg(0, ios::end);   
	str.reserve(f.tellg());
	f.seekg(0, ios::beg);

	str.assign((istreambuf_iterator<char>(f)),
		istreambuf_iterator<char>());

	f.close();

	return str;
}

/******************************************************************************
//complete function implementations (with associated documenting)
TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO
******************************************************************************/